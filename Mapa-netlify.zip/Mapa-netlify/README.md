# Mapa — wersja Netlify

Ta wersja używa Netlify Functions i Netlify Blobs. Konta, sesje, grupy, mapy oraz przesyłane zdjęcia są przechowywane po stronie Netlify. Pliki `accounts.json`, `group-maps` i `group-images` z wersji lokalnej nie są publikowane.

## Publikacja przez Git

1. Umieść zawartość tego folderu w repozytorium GitHub, GitLab albo Bitbucket.
2. W Netlify wybierz **Add new project → Import an existing project** i wskaż repozytorium.
3. Netlify odczyta `netlify.toml`; katalog publikacji to `public`, a funkcje są w `netlify/functions`.
4. Wdróż projekt. Netlify Blobs zostanie użyte automatycznie przez funkcję.
5. Otwórz adres `*.netlify.app` i utwórz pierwsze konto.

Pierwsze konto otrzyma dane z lokalnego `data.json`, które zostały zapisane w `netlify/functions/seed-data.mjs`. Dotychczasowe zdjęcia znajdują się w `public/images`.

## Publikacja z Netlify CLI

W terminalu, w tym folderze:

```powershell
npm install
npx netlify login
npx netlify deploy --prod
```

Nie używaj Netlify Drop do przeciągnięcia samego folderu `public`, ponieważ opublikowałoby to tylko interfejs bez funkcji logowania i zapisu.

## Uruchomienie lokalne

```powershell
npm install
npx netlify dev
```

Następnie otwórz adres pokazany przez Netlify CLI, zwykle `http://localhost:8888`.

## Kopia zapasowa

Dane produkcyjne można przeglądać w panelu projektu Netlify w **Data & Storage → Blobs**. Używane magazyny to `mapka-auth`, `mapka-maps` i `mapka-images`.
